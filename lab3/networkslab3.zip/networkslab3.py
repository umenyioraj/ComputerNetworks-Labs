#Getting the layers ready for lab3 portion
import random
arr = []
arr1 = []
arr1trail= [0,0]
arr2 = []
arr3head = [1,0,1,0]
arr3 = []
arr3trail = [1,1,1,1]

for i in range(0,16):
   num = random.randrange(0,2)
   arr.append(num)

for i in range(0,4):
   arr.insert(0,0)
#print(arr)

arr.extend(arr1trail)
#print(arr)

arr.insert(0,0)
arr.insert(0,1)
arr.insert(0,0)
arr.insert(0,1)

arr.extend(arr3trail)

print("Level 4" , arr)

#transmit data

for i in arr:
   arr3.append(i)
print("Level 3", arr3)
#print(len(arr3))

for i in range(len(arr)):
   if i in range(4,26):
      arr2.append(arr[i])
print("Level 2", arr2)
#print(len(arr2))

for i in range(len(arr2)):
   if i in range(4,20):
      arr1.append(arr2[i])
print("Level 1", arr1)
#print(len(arr1))


#Lab 3 portion
def char_stuff(a):
   beg = 0
   end = 5
   dle_char = 0
   while end <= len(a)+1:
      if a[beg:end] == [0,1,1,1,0]:
         a[beg:beg] = [0,1,1,1,1]
         beg +=10
         end = beg +5
         dle_char +=1
      else:
         end += 1
         beg +=1
   seq = [0,1,1,1,0]
   print('Char Stuff Transmit',seq + a + seq)

   dle = [0,1,1,1,1]
   beg = 0
   end = 5
   while end < len(a)+1:
      if a[beg:end] == dle and dle_char != 0:
         a[beg:end] = []
         dle_char -= 1
      else:
         beg +=1
         end +=1
   print('char stuff recieved',seq + a + seq)


data2 = [0,1,0,1,1,0,1,0,0,0,0,1,1,0,1,1]

def bit_stuff(a):
   beg = 0
   end = 3
   seq = [0,1,1,1,0]
   while beg < len(a)-2:
      if a[beg:end] == [0,1,1]:
         if end+1 != len(a) or a[beg:end+2] != seq:
            a.insert(end,0)
            beg = end + 1
            end += 4
      else:
         end +=1
         beg +=1
   print('Bit Stuff Transmitted',seq + a + seq)
   beg = 0
   end = 4
   while end < len(a) +1:
      
      if a[beg:end] == [0,1,1,0]:
         a.pop(end-1)
         beg = end -1
         end = beg +4
      else:
         beg+=1
         end +=1
   print('Bit Stuff Recieved',seq + a + seq)
   

print(arr3)
msb = input('Enter MSB: ')
if int(msb) == 1:
   bit_stuff(arr3)
elif int(msb) == 0:
   char_stuff(arr3)
